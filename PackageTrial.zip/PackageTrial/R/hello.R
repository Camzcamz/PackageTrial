
# Hello, world!
#
# This is an example function named 'hello'
# which prints 'Hello, world!'.
#
# You can learn more about package authoring with RStudio at:
#
#   http://r-pkgs.had.co.nz/
#
# Some useful keyboard shortcuts for package authoring:
#
#   Build and Reload Package:  'Cmd + Shift + B'
#   Check Package:             'Cmd + Shift + E'
#   Test Package:              'Cmd + Shift + T'

hello <- function() {
  print("Hello, world!")
}
library("roxygen2")
# Add skeleton by doing ctrl alt shift r
# @export - function is public and can be used by anyone not jst between functions
# ::: this is a private function and its the only way to access it
library("usethis")
library("devtools")


#' Sum of x and y
#'
#' @param x is a vector or dbl
#' @param y is a vector or dbl
#'
#' @return
#' @export
#'
#' @examples
A1 <- function(x,y) {x + y}

# do devtools::document() in the console to save as a file in man folder
# Ntes: dont load package but call it - so you dont charge it in your memory -
# several packages have the same name for the function - charge only the function that you want from the package
# dont use source

#somepackage::somefun()

